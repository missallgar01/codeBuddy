# Flask Classroom — Python Coding Site

Features: teacher/student roles, class invite codes, assignments with Markdown + images, Monaco editor, in-browser run, automated grading (JSON mark scheme), Docker + SQLite.

## Quickstart (Docker)
```
cp .env.example .env
docker compose up --build -d
docker compose exec web python manage.py
# http://localhost:8000
```
Use absolute DB path in Docker: `DATABASE_URL=sqlite:////app/instance/classroom.db`

## Accounts
- Admin teacher (from .env): `ADMIN_EMAIL` / `ADMIN_PASSWORD`
- Dummy student: `student@example.com` / `Stud3nt!123` (override with `STUDENT_EMAIL`, `STUDENT_PASSWORD`)

## Teacher invite
Set `TEACHER_INVITE_TOKEN` in `.env`, then register at `/register-teacher`.
